// Hard-coded ID for the browser phone, so we can call it. Should be a unique
// string identifier for your user, like their e-mail address or username
var CLIENT_ID = 'browser.browserkins@gmail.com';

// Show a web page that will have a Twilio Client powered soft phone. Generate
// a capability token to power it here on the server.
exports.show = function(request, response) {

};

// Render TwiML instructions for the outbound call initiated by the browser
exports.outboundTwiml = function(request, response) {

};

// Update the configured Twilio number for this demo to send all incoming
// calls to this server
exports.configureNumber = function(request, response) {

};
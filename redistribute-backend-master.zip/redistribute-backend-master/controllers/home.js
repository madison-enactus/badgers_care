// Render home page
exports.show = function(request, response) {
    response.render('index');
};
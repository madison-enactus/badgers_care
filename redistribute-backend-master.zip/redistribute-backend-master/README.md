# redistribute-backend
The backend that handles messaging and databasing.

Project forked from Twilio Node.js and Express starter project. 
Please check documentation here for it here: https://github.com/TwilioDevEd/starter-node-express
